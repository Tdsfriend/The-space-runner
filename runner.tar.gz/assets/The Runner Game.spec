# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['BIG_PROJECT.py'],
    pathex=[],
    binaries=[],
    datas=[('Audio', 'Audio'), ('Player', 'Player'), ('Snail', 'Snail'), ('Fly', 'Fly'), ('Ground.png', '.'), ('Sky.png', '.'), ('Pixeltype.ttf', '.')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='The Runner Game',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['SlimeIcon.ico'],
)
