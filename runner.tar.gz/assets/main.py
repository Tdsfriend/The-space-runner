import pygame
import time
import os
import sys
from random import randint
from sys import exit
import asyncio


def resource_path(relative_path):
    if hasattr(sys, "_MEIPASS"):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))

    return os.path.join(base_path, relative_path)


def display_score():
    current_time = int(pygame.time.get_ticks() / 1000) - start_time
    score_surf = test_font.render(
        f"Score: {current_time}", False, (64, 64, 64)
    )
    score_rect = score_surf.get_rect(center=(400, 50))
    WIN.blit(score_surf, score_rect)
    return current_time


def obstacle_movement(obstacle_list):
    if obstacle_list:
        for obstacle_rect in obstacle_list:
            obstacle_rect.x -= 5

            if obstacle_rect.bottom == 300:
                WIN.blit(snail_surf, obstacle_rect)
            else:
                WIN.blit(fly_surf, obstacle_rect)

        obstacle_list = [
            obstacle for obstacle in obstacle_list
            if obstacle.x > -100
        ]
        return obstacle_list

    return []


def collisions(player, obstacles):
    if obstacles:
        for obstacle_rect in obstacles:
            if player.colliderect(obstacle_rect):
                return False
    return True


def player_animation():
    global player_surf, player_index

    if player_rect.bottom < 300:
        player_surf = player_jump
    else:
        player_index += 0.08
        if player_index >= len(player_walk):
            player_index = 0
        player_surf = player_walk[int(player_index)]


pygame.init()

WIN = pygame.display.set_mode((800, 400))
pygame.display.set_caption("The Runner Game")

player_surface = pygame.image.load(
    resource_path("Player/walk_1.png")
)
pygame.display.set_icon(player_surface)

clock = pygame.time.Clock()
test_font = pygame.font.Font(resource_path("Pixeltype.ttf"), 50)

game_active = False
start_time = 0
score = 0

# Background music
pygame.mixer.music.load(resource_path("Audio/music.ogg"))
pygame.mixer.music.set_volume(0.6)
pygame.mixer.music.play(loops=-1)

# Background
ground_surf = pygame.image.load(
    resource_path("Ground.png")
).convert()
sky_surface = pygame.image.load(
    resource_path("Sky.png")
).convert()

# Snail
snail_frame_1 = pygame.image.load(
    resource_path("Snail/snail1.png")
).convert_alpha()
snail_frame_2 = pygame.image.load(
    resource_path("Snail/snail2.png")
).convert_alpha()

snail_frames = [snail_frame_1, snail_frame_2]
snail_frame_index = 0
snail_surf = snail_frames[snail_frame_index]

# Fly
fly_frame1 = pygame.image.load(
    resource_path("Fly/fly1.png")
).convert_alpha()
fly_frame2 = pygame.image.load(
    resource_path("Fly/fly2.png")
).convert_alpha()

fly_frames = [fly_frame1, fly_frame2]
fly_frame_index = 0
fly_surf = fly_frames[fly_frame_index]

obstacle_rect_list = []

# Player
player_walk_1 = pygame.image.load(
    resource_path("Player/walk_1.png")
).convert_alpha()
player_walk_2 = pygame.image.load(
    resource_path("Player/walk_2.png")
).convert_alpha()

player_walk = [player_walk_1, player_walk_2]
player_index = 0

player_jump = pygame.image.load(
    resource_path("Player/jump.png")
).convert_alpha()

player_surf = player_walk[player_index]
player_rect = player_surf.get_rect(midbottom=(80, 300))
player_gravity = 0

# Intro screen
player_stand = pygame.image.load(
    resource_path("Player/stand.png")
).convert_alpha()
player_stand = pygame.transform.rotozoom(player_stand, 0, 2)
player_stand_rect = player_stand.get_rect(center=(400, 200))

game_name = test_font.render(
    "Pixel Run", False, (111, 196, 169)
)
game_name_rect = game_name.get_rect(center=(410, 80))

game_message = test_font.render(
    "Press space to run", False, (111, 196, 169)
)
game_message_rect = game_message.get_rect(center=(400, 320))

# Sounds
jump_sound = pygame.mixer.Sound(
    resource_path("Audio/jump.ogg")
)
jump_sound.set_volume(0.4)

# Browser-compatible timers
last_obstacle_time = 0
last_snail_animation_time = 0
last_fly_animation_time = 0


async def main():
    global last_obstacle_time, last_snail_animation_time
    global last_fly_animation_time
    global player_gravity, game_active, start_time, score
    global score_message, score_message_rect, obstacle_rect_list
    global fly_frame_index, snail_frame_index, fly_surf, snail_surf

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return

            if game_active:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if player_rect.collidepoint(event.pos) and player_rect.bottom >= 300:
                        player_gravity = -20
                        jump_sound.play()

                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_SPACE, pygame.K_UP) and player_rect.bottom >= 300:
                        player_gravity = -20
                        jump_sound.play()

            else:
                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_SPACE, pygame.K_UP):
                        game_active = True
                        start_time = pygame.time.get_ticks() // 1000
                        last_obstacle_time = pygame.time.get_ticks()

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if player_stand_rect.collidepoint(event.pos):
                        game_active = True
                        start_time = pygame.time.get_ticks() // 1000
                        last_obstacle_time = pygame.time.get_ticks()

        current_time = pygame.time.get_ticks()

        if game_active:
            # Spawn obstacles every 1.5 seconds
            if current_time - last_obstacle_time >= 1500:
                if randint(0, 2):
                    obstacle_rect_list.append(
                        snail_surf.get_rect(
                            bottomright=(randint(900, 1100), 300)
                        )
                    )
                else:
                    obstacle_rect_list.append(
                        fly_surf.get_rect(
                            bottomright=(randint(900, 1100), 210)
                        )
                    )

                last_obstacle_time = current_time

            # Animate snail
            if current_time - last_snail_animation_time >= 500:
                snail_frame_index = 1 - snail_frame_index
                snail_surf = snail_frames[snail_frame_index]
                last_snail_animation_time = current_time

            # Animate fly
            if current_time - last_fly_animation_time >= 200:
                fly_frame_index = 1 - fly_frame_index
                fly_surf = fly_frames[fly_frame_index]
                last_fly_animation_time = current_time

            # Draw active game
            WIN.blit(sky_surface, (0, 0))
            WIN.blit(ground_surf, (0, 300))

            score = display_score()

            player_gravity += 0.9
            player_rect.y += player_gravity

            if player_rect.bottom >= 300:
                player_rect.bottom = 300

            player_animation()
            WIN.blit(player_surf, player_rect)

            obstacle_rect_list = obstacle_movement(obstacle_rect_list)
            game_active = collisions(player_rect, obstacle_rect_list)

        else:
            # Draw intro / game-over screen
            WIN.fill((94, 129, 162))
            WIN.blit(player_stand, player_stand_rect)

            obstacle_rect_list.clear()
            player_rect.midbottom = (80, 300)
            player_gravity = 0

            score_message = test_font.render(
                f"Your score: {score}", False, (11, 196, 169)
            )
            score_message_rect = score_message.get_rect(center=(400, 330))

            WIN.blit(game_name, game_name_rect)

            if score == 0:
                WIN.blit(game_message, game_message_rect)
            else:
                WIN.blit(score_message, score_message_rect)

        pygame.display.flip()
        await asyncio.sleep(0)
        clock.tick(60)


asyncio.run(main())
